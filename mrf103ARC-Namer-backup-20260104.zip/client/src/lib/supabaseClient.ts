export const supabase = null;

export const isSupabaseConfigured = () => false;
