import React, { useState, useEffect, useRef } from 'react';
import { PATENTS, TEAM } from './constants';
import TerminalLoader from './components/TerminalLoader';
import PatentCard from './components/PatentCard';
import LiveMonitor from './components/LiveMonitor';
import AIGuidance from './components/AIGuidance'; // Import the new component
import { 
  Shield, 
  Globe, 
  Target, 
  Server, 
  MapPin, 
  Wifi, 
  Radio, 
  TriangleAlert,
  Fingerprint,
  Menu,
  Terminal,
  Lock,
  Power,
  Cpu,
  Zap
} from 'lucide-react';

const App: React.FC = () => {
  const [appState, setAppState] = useState<'boot' | 'guidance' | 'active'>('boot');
  const [lang, setLang] = useState<'en' | 'ar'>('en');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'patents' | 'team'>('dashboard');
  const [logs, setLogs] = useState<string[]>([]);
  const logContainerRef = useRef<HTMLDivElement>(null);
  const [isSidebarOpen, setSidebarOpen] = useState(false);

  const toggleLang = () => setLang(prev => prev === 'en' ? 'ar' : 'en');

  // Random System Logs Generator
  useEffect(() => {
    if (appState !== 'active') return;
    
    const messages = [
        "GPIO 33: Nominal",
        "BME688: VOC 2.5ppm",
        "INMP441: Noise Floor -90dB",
        "ESP32-S3: Temp 42°C",
        "Connection: Secure (SSL/TLS)",
        "Latency: 12ms",
        "Packets: 1024/s",
        "Scanning frequencies...",
        "Heartbeat: OK",
        "Memory: 65% Free"
    ];

    const interval = setInterval(() => {
      const msg = messages[Math.floor(Math.random() * messages.length)];
      const time = new Date().toLocaleTimeString('en-US', { hour12: false });
      setLogs(prev => [`[${time}] ${msg}`, ...prev].slice(0, 50)); // Keep last 50
    }, 2000);

    return () => clearInterval(interval);
  }, [appState]);

  // Stage 1: Terminal Loader
  if (appState === 'boot') {
    return <TerminalLoader onComplete={() => setAppState('guidance')} lang={lang} />;
  }

  // Stage 2: AI Guidance & Welcome
  if (appState === 'guidance') {
    return <AIGuidance onComplete={() => setAppState('active')} lang={lang} setLang={setLang} />;
  }

  const content = {
    en: {
      header: {
        title: "X-BIO SENTINEL",
        subtitle: "Class-7 Autonomous Defense Node",
        location: "RIYADH, KSA [SECURE]",
        status: "OPERATIONAL"
      },
      nav: {
        dashboard: "CMD // DASHBOARD",
        patents: "INV // PATENTS",
        team: "HR // PERSONA",
      },
      hero: {
        warning: "AUTHORIZED PERSONNEL ONLY // TOP SECRET",
        mission: "The X-Bio Sentinel is not just a device. It is an Autonomous Cognitive Node capable of sensing physical and metaphysical threats. Developed in Riyadh with 100% localized intellectual property.",
      },
      stats: {
        uptime: "SYSTEM UPTIME",
        defense: "DEFENSE MODE",
        threat: "THREAT LEVEL",
      },
      logs: "SYSTEM LOGS",
      hw: "HARDWARE STATUS"
    },
    ar: {
      header: {
        title: "X-BIO SENTINEL",
        subtitle: "عقدة الدفاع الذاتي من الفئة-7",
        location: "الرياض، المملكة العربية السعودية [آمن]",
        status: "نشط"
      },
      nav: {
        dashboard: "القيادة // اللوحة الرئيسية",
        patents: "الابتكارات // براءات الاختراع",
        team: "الموارد // الشخصيات",
      },
      hero: {
        warning: "للمصرح لهم فقط // سري للغاية",
        mission: "نظام X-Bio Sentinel ليس مجرد جهاز. هو عقدة إدراكية مستقلة قادرة على استشعار التهديدات المادية والماورائية. تم تطويره في الرياض بملكية فكرية محلية 100%.",
      },
      stats: {
        uptime: "وقت التشغيل",
        defense: "وضع الدفاع",
        threat: "مستوى التهديد",
      },
      logs: "سجلات النظام",
      hw: "حالة العتاد"
    }
  };

  const t = content[lang];
  const isRTL = lang === 'ar';

  return (
    <div className={`min-h-screen font-sans text-gray-200 bg-xb-black selection:bg-xb-green selection:text-black overflow-hidden flex flex-col ${isRTL ? 'rtl' : 'ltr'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      
      {/* Background FX */}
      <div className="fixed inset-0 crt-overlay z-50 pointer-events-none opacity-30"></div>
      <div className="fixed inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10 z-0"></div>
      <div className="fixed top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-xb-green to-transparent opacity-50 z-50"></div>

      {/* HEADER */}
      <header className="border-b border-xb-green/20 bg-xb-dark/90 backdrop-blur-md z-40 h-16 shrink-0">
        <div className="h-full px-4 md:px-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button className="md:hidden text-xb-green" onClick={() => setSidebarOpen(!isSidebarOpen)}>
               <Menu />
            </button>
            <Shield className="w-8 h-8 text-xb-green animate-[pulse_3s_infinite]" />
            <div className="flex flex-col">
              <h1 className="font-display font-bold text-lg md:text-xl tracking-wider text-white leading-none">
                {t.header.title}
              </h1>
              <span className="font-tech text-[10px] md:text-xs text-xb-green/60 uppercase tracking-[0.2em]">
                {t.header.subtitle}
              </span>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-8 font-mono text-xs text-gray-500">
             <div className="flex items-center gap-2 px-3 py-1 bg-black/40 rounded border border-white/5">
                <MapPin className="w-3 h-3 text-xb-red" />
                <span className="tracking-tighter">{t.header.location}</span>
             </div>
             <div className="flex items-center gap-2 px-3 py-1 bg-black/40 rounded border border-white/5">
                <div className="w-2 h-2 bg-xb-green rounded-full animate-pulse"></div>
                <span className="text-xb-green tracking-widest">{t.header.status}</span>
             </div>
             <button 
              onClick={toggleLang}
              className="flex items-center gap-2 px-3 py-1 border border-xb-green/30 rounded hover:bg-xb-green/10 transition-colors font-mono text-xs text-xb-green"
            >
              <Globe className="w-3 h-3" />
              {lang === 'en' ? 'AR' : 'EN'}
            </button>
          </div>
        </div>
      </header>

      {/* MAIN LAYOUT */}
      <div className="flex flex-1 overflow-hidden relative">
        
        {/* SIDEBAR NAVIGATION (Desktop) */}
        <nav className={`fixed inset-y-0 left-0 w-64 bg-xb-dark/95 backdrop-blur-xl border-r border-xb-green/10 transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 md:static md:w-64 transition-transform duration-300 z-30 flex flex-col`}>
           <div className="p-6 space-y-2 mt-16 md:mt-0">
              <button 
                onClick={() => { setActiveTab('dashboard'); setSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-sm border-l-2 transition-all duration-200 group ${activeTab === 'dashboard' ? 'bg-xb-green/10 border-xb-green text-white' : 'border-transparent text-gray-500 hover:text-xb-green hover:bg-white/5'}`}
              >
                 <Server className="w-4 h-4" />
                 <span className="font-display text-sm tracking-widest">{t.nav.dashboard}</span>
              </button>
              
              <button 
                onClick={() => { setActiveTab('patents'); setSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-sm border-l-2 transition-all duration-200 group ${activeTab === 'patents' ? 'bg-xb-cyan/10 border-xb-cyan text-white' : 'border-transparent text-gray-500 hover:text-xb-cyan hover:bg-white/5'}`}
              >
                 <Target className="w-4 h-4" />
                 <span className="font-display text-sm tracking-widest">{t.nav.patents}</span>
              </button>
              
              <button 
                onClick={() => { setActiveTab('team'); setSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-sm border-l-2 transition-all duration-200 group ${activeTab === 'team' ? 'bg-xb-gold/10 border-xb-gold text-white' : 'border-transparent text-gray-500 hover:text-xb-gold hover:bg-white/5'}`}
              >
                 <Fingerprint className="w-4 h-4" />
                 <span className="font-display text-sm tracking-widest">{t.nav.team}</span>
              </button>
           </div>

           {/* Hardware Status Panel (Sidebar Bottom) */}
           <div className="mt-auto p-6 border-t border-white/5">
              <h3 className="font-tech text-xs text-gray-500 uppercase mb-4 flex items-center gap-2">
                 <Cpu className="w-3 h-3" /> {t.hw}
              </h3>
              <div className="space-y-3 font-mono text-[10px]">
                 <div className="flex justify-between items-center">
                    <span className="text-gray-400">ESP32-S3 Core</span>
                    <span className="text-xb-green">ONLINE</span>
                 </div>
                 <div className="w-full bg-gray-800 h-1 rounded-full overflow-hidden">
                    <div className="bg-xb-green w-[34%] h-full animate-[pulse_2s_infinite]"></div>
                 </div>

                 <div className="flex justify-between items-center">
                    <span className="text-gray-400">Kinetic Silo</span>
                    <span className="text-xb-gold">STANDBY</span>
                 </div>
                 <div className="w-full bg-gray-800 h-1 rounded-full overflow-hidden">
                    <div className="bg-xb-gold w-[100%] h-full"></div>
                 </div>

                 <div className="flex justify-between items-center">
                    <span className="text-gray-400">Audio Amp</span>
                    <span className="text-xb-red">ARMED</span>
                 </div>
                 <div className="w-full bg-gray-800 h-1 rounded-full overflow-hidden">
                    <div className="bg-xb-red w-[10%] h-full"></div>
                 </div>
              </div>
           </div>
        </nav>

        {/* CONTENT AREA */}
        <main className="flex-1 overflow-y-auto overflow-x-hidden relative bg-black/50 p-4 md:p-8">
            
            {/* Dashboard View */}
            {activeTab === 'dashboard' && (
              <div className="space-y-6 animate-fadeIn">
                
                {/* Threat Banner */}
                <div className="relative overflow-hidden rounded border border-xb-red/40 bg-gradient-to-r from-xb-red/10 to-transparent p-4 md:p-6 flex items-start md:items-center gap-4 group">
                   <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                      <TriangleAlert className="w-24 h-24" />
                   </div>
                   <div className="p-3 bg-xb-red/20 rounded-full border border-xb-red/50 animate-pulse">
                      <TriangleAlert className="w-6 h-6 text-xb-red" />
                   </div>
                   <div className="z-10">
                      <h2 className="font-display font-bold text-white text-lg tracking-wider">{t.hero.warning}</h2>
                      <p className="font-mono text-xs md:text-sm text-gray-300 mt-1 max-w-2xl leading-relaxed opacity-80">
                         {t.hero.mission}
                      </p>
                   </div>
                </div>

                {/* Main Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    
                    {/* Metrics (Top) */}
                    <div className="lg:col-span-12 grid grid-cols-1 md:grid-cols-3 gap-4">
                       {[
                         { icon: Radio, label: t.stats.threat, val: 'CLASS 0', sub: 'NO ANOMALIES', color: 'xb-green' },
                         { icon: Shield, label: t.stats.defense, val: 'FDIP-11', sub: 'ARMED / READY', color: 'xb-cyan' },
                         { icon: Zap, label: t.stats.uptime, val: '99.99%', sub: 'SINCE REBOOT', color: 'xb-gold' }
                       ].map((stat, i) => (
                         <div key={i} className={`bg-xb-dark/60 border border-white/5 p-4 rounded relative overflow-hidden group hover:border-${stat.color}/50 transition-colors`}>
                            <div className={`absolute -right-4 -top-4 opacity-5 group-hover:opacity-10 transition-opacity text-${stat.color}`}>
                               <stat.icon className="w-20 h-20" />
                            </div>
                            <span className={`font-tech text-xs text-${stat.color} tracking-widest`}>{stat.label}</span>
                            <div className="font-display text-2xl md:text-3xl text-white mt-1 mb-1">{stat.val}</div>
                            <span className="font-mono text-[10px] text-gray-500 uppercase">{stat.sub}</span>
                         </div>
                       ))}
                    </div>

                    {/* Live Chart (Left Large) */}
                    <div className="lg:col-span-8 h-[400px]">
                        <LiveMonitor lang={lang} />
                    </div>

                    {/* Right Panel (Logs & Kill Switch) */}
                    <div className="lg:col-span-4 flex flex-col gap-4 h-[400px]">
                       
                       {/* Terminal Logs */}
                       <div className="flex-1 bg-black border border-white/10 rounded p-4 font-mono text-[10px] md:text-xs overflow-hidden flex flex-col">
                          <div className="flex justify-between items-center mb-2 border-b border-white/10 pb-2">
                             <div className="flex items-center gap-2 text-xb-green">
                                <Terminal className="w-3 h-3" />
                                <span className="uppercase tracking-widest">{t.logs}</span>
                             </div>
                             <div className="w-2 h-2 rounded-full bg-xb-green animate-blink"></div>
                          </div>
                          <div className="flex-1 overflow-y-auto space-y-1 opacity-70 scrollbar-hide" ref={logContainerRef}>
                             {logs.map((log, i) => (
                               <div key={i} className="text-gray-400 border-l border-white/5 pl-2 hover:bg-white/5 transition-colors">
                                 <span className="text-xb-green/50">{'>'}</span> {log}
                               </div>
                             ))}
                          </div>
                       </div>

                       {/* Kill Switch Visual */}
                       <div className="h-32 bg-red-950/20 border border-xb-red/30 rounded p-4 flex items-center justify-between relative overflow-hidden group">
                          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/diagmonds-light.png')] opacity-10"></div>
                          <div className="z-10">
                             <h3 className="font-display text-xb-red text-sm font-bold uppercase tracking-widest">Master Override</h3>
                             <p className="font-mono text-[10px] text-red-400 mt-1">GPIO 33 - PHYSICAL KEY REQUIRED</p>
                          </div>
                          <div className="w-16 h-16 rounded-full border-4 border-red-900 bg-black flex items-center justify-center shadow-[0_0_20px_rgba(255,0,0,0.2)] group-hover:shadow-[0_0_30px_rgba(255,0,0,0.5)] transition-shadow cursor-not-allowed z-10">
                             <Power className="w-8 h-8 text-red-800" />
                          </div>
                       </div>

                    </div>
                </div>
              </div>
            )}

            {/* Patents View */}
            {activeTab === 'patents' && (
              <div className="space-y-6 animate-fadeIn">
                 <div className="flex flex-col md:flex-row justify-between items-end border-b border-xb-cyan/20 pb-4 gap-4">
                   <div>
                      <h2 className="font-display text-3xl text-white">{t.nav.patents} <span className="text-xb-cyan text-lg align-top">19</span></h2>
                      <p className="font-mono text-xs text-gray-400 mt-2 max-w-3xl leading-relaxed opacity-80">
                        {lang === 'en' 
                          ? "Exclusive intellectual property registered with SAIP. These inventions form the backbone of the X-Bio Sentinel's autonomous capabilities. Unauthorized reproduction is a federal offense." 
                          : "ملكية فكرية حصرية مسجلة لدى الهيئة السعودية للملكية الفكرية. تشكل هذه الابتكارات العمود الفقري لقدرات النظام المستقلة."}
                      </p>
                   </div>
                   <div className="flex gap-2">
                      <div className="px-3 py-1 bg-xb-cyan/10 border border-xb-cyan/30 rounded text-[10px] font-tech text-xb-cyan">CONFIDENTIAL</div>
                   </div>
                 </div>

                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                   {PATENTS[lang].map((patent) => (
                     <PatentCard key={patent.code} patent={patent} lang={lang} />
                   ))}
                 </div>
              </div>
            )}

            {/* Team View */}
            {activeTab === 'team' && (
              <div className="space-y-6 animate-fadeIn">
                  <div className="flex flex-col md:flex-row justify-between items-end border-b border-xb-gold/20 pb-4 gap-4">
                   <div>
                      <h2 className="font-display text-3xl text-white">{t.nav.team}</h2>
                      <p className="font-mono text-xs text-gray-400 mt-2 max-w-2xl opacity-80">
                        {lang === 'en' 
                          ? "The Neural Hierarchy. A combination of human leadership and specialized AI agents designed for specific autonomous tasks." 
                          : "التسلسل الهرمي العصبي. مزيج من القيادة البشرية ووكلاء الذكاء الاصطناعي المتخصصين."}
                      </p>
                   </div>
                   <div className="px-3 py-1 bg-xb-gold/10 border border-xb-gold/30 rounded text-[10px] font-tech text-xb-gold">ACCESS LEVEL: MAX</div>
                 </div>

                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {TEAM[lang].map((member) => (
                      <div key={member.id} className="bg-gradient-to-br from-xb-gray/40 to-black p-6 border-l-2 border-xb-gold relative overflow-hidden hover:bg-xb-gray/60 transition-colors group">
                         {/* Watermark ID */}
                         <div className="absolute -right-4 -top-4 text-white/5 font-display text-6xl font-bold opacity-0 group-hover:opacity-10 transition-opacity">
                            {member.id}
                         </div>

                         <div className="flex items-center gap-4 mb-4 relative z-10">
                            <div className="w-12 h-12 rounded bg-xb-gold/10 flex items-center justify-center border border-xb-gold/30 shrink-0">
                               {/* Icon Logic placeholder if needed, using generic text for now */}
                               <span className="font-display font-bold text-xb-gold text-sm">{member.id.substring(0,3)}</span>
                            </div>
                            <div>
                              <h3 className="font-display text-white text-lg tracking-wide">{member.name}</h3>
                              <span className="font-tech text-xs text-gray-400 uppercase tracking-widest block mt-0.5">{member.role}</span>
                            </div>
                         </div>
                         
                         <div className="mb-4 relative z-10">
                            <span className="inline-block px-2 py-0.5 bg-black/50 text-[10px] font-mono text-xb-gold border border-xb-gold/20 rounded shadow-[0_0_10px_rgba(255,215,0,0.1)]">
                               {member.clearance}
                            </span>
                         </div>

                         <p className="font-mono text-xs text-gray-400 leading-relaxed border-t border-white/5 pt-3 relative z-10">
                            {member.description}
                         </p>
                      </div>
                    ))}
                 </div>
              </div>
            )}

        </main>
      </div>
    </div>
  );
};

export default App;